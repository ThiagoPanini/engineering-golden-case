from app.src.get_b3_active_tickers.presentation import save_tickers_info_presentation

save_tickers_info_presentation.handler(None, None)
